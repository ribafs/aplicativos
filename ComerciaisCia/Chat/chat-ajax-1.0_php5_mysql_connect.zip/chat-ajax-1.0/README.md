# chat-ajax

## Esta é a versão original deste chat

Ela usa a biblioeca de conexão mysql e requer o PHP 5

## Observação

Encontrei este código, mas não mais consigo encontrar o autor ou seu site. Originalmente em italiano e usava a biblioteca mysql (mysql_query).
Então converti para PDO e fiz alguns poucos ajustes.

## Alerta

Lembrando que este pequeno exemplo hão tem qualquer autenticação nem mesmo usa hash nas senhas. Portanto para usá-lo em produção precisa estar numa área protegida e/ou usar hashs para a proteção dos dados.


## Abaixo está o texto do README original.

Gostaria de dar o crédito ao autor.

Chat PHP MYSQL AJAX

Este chat ha sido creado con el fin de enseñar conceptos basicos de programacion
en php, mysql, ajax, jquery

Chat creado mediante video tutorial en youtube

Chat:
https://www.youtube.com/watch?v=SID4-LMbpqk

Canal:
https://www.youtube.com/AnySlehider

## URL deste projeto

Para que não esqueçamos de onde baixamos - https://github.com/ribafs/chat-ajax

## Licença

MIT
