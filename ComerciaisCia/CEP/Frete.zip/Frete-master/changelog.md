# Changelog

### 0.2.*

* Adicionada licensa MIT;
* Adicionado namespace `Correios`;

