<?php

namespace EscapeWork\Frete\Correios;

use EscapeWork\Frete\Result;

class ConsultaCEPResult extends Result
{

}
