<?php
require_once "SalesCustomersProducts.php";
$SalesCustomersProducts = new SalesCustomersProducts;
$SalesCustomersProducts->run()->render();
?>    
