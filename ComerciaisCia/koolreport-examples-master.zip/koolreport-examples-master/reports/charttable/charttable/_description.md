`koolreport/charttable` is package to show in both chart and table together.

```
\koolreport\charttable\ChartTable::create(array(
    "name" => "charttable1",
    "dataSource" => $this->dataStore('myDatastore')
));
```
