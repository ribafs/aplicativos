
You could use various types of output formats for QRCode