The report summarize sale data by customers. Sale data is pulled from database, grouping by customers then order data by the sale amount. The report only show the top 10 customers who have the highest value of transaction with company.

The report use `BarChart` to better visualize sale data by customers. The detail data are shown in `Table` below the chart.