<?php

class MyReport extends \koolreport\KoolReport
{

}