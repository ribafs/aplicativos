The examples show how to let user reorder the column by dragging column header.

```
DataTables::create(array(
    ...
    "options"=>array(
        "colReorder"=>true
    )
));
```