The example demonstrate how to add page break in PDF generation. The example requires token key to run and you can follow this instruction in below link to get token key:

[Get ChromeHeadless.io Token Key](https://www.koolreport.com/docs/cloudexport/chromeheadlessio/#get-token-key).

Enjoy!