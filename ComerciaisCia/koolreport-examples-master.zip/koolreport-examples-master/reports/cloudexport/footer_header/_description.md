The example demonstrate how to use CloudExport package with ChromeHeadless.io service to generate PDF and JPG. The example also demonstrates how to add header and footer to PDF. The example requires token key to run and you can follow this instruction in below link to get token key:

[Get ChromeHeadless.io Token Key](https://www.koolreport.com/docs/cloudexport/chromeheadlessio/#get-token-key).

Enjoy!