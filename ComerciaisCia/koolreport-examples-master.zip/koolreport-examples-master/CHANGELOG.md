# ChangeLog

## Version 1.3.0

1. Fix datagrid examples

## Version 1.2.0

1. Fix the composer file to indicate the version 4 of KoolReport

## Version 1.1.1

1. Fix the Export example with wrong path

## Version 1.1.0

1. Adding the `load.koolreport.php` to easily configure path for koolreport's library
2. Adding examples for `Amazing` theme