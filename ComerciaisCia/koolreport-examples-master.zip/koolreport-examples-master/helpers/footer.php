<footer class="text-muted bg-dark">
    <div class="container">
    <p class="float-right">
        <a href="#">Back To top</a>
    </p>
    <p>
        <a href="https://www.koolreport.com">Website</a> -
        <a href="https://github.com/koolphp/koolreport">Github</a> -
        <a href="https://twitter.com/getkoolreport">Twitter</a> -
        <a href="https://facebook.com/koolreport">Facebook</a>
    </p>
    <p style="margin-top:2rem">
        Designed and built with <i class="fa fa-heart-o text-danger"></i> by <a href="https://www.koolphp.net">KoolPHP Inc</a>.
    </p>
    <p>Code licensed <a href="https://www.koolreport.com/license#mit-license">MIT</a>.</p>
    </div>
</footer>