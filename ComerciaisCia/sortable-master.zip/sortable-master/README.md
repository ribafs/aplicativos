## Sortable

<a href="https://eager.io/app/sortable/install?source=button">
  <img src="https://install.eager.io/install-button.png" border="0" width="126">
</a>

##### [Demo](http://github.hubspot.com/sortable/docs/welcome) &nbsp;&nbsp; [Documentation](http://github.hubspot.com/sortable)

Sortable is an open-source JavaScript and CSS library which adds sorting functionality to tables. It is tiny (`<2kb` min+gzip) and has no dependencies.
