<?php

header('LOCATION: login.php');

?>
