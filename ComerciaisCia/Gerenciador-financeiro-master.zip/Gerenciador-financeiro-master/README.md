# Gerenciador-financeiro
Gerenciador financeiro para pequenas empresas, possibilidade de adicionar, editar, excluir clientes, faturas, débitos, formas de
pagamentos, emitir boletos, envio por email.

O usuário padrão é teste e a senha é 1234

<img src="gerenciador.png">


- Crie um banco no MySQL
- Importe o script db.sql
- Configurre config/mysql.php

-	$urlsistema = 'http://localhost/financeiro/';
-	$bd_serv = '127.0.0.1';
-	$bd_user = 'root';
-	$bd_pass = 'root';
-	$bd_banc = 'testes';
