Brazil.db
=========================

Banco de dados Postgres/MySQL com todas as cidades e estados brasileiras, incluindo ruas, latitudes, longitudes e CEPs.

**Última atualização: Agosto/2013**

Dados de latitude/longitude extraídos do [FTP do IBGE](ftp://geoftp.ibge.gov.br/organizacao_territorial/localidades/Google_KML/BR%20Localidades%202010%20v1.kml) em 31/12/2012

Dados de CEP extraídos do forum [Javafree.org](http://javafree.uol.com.br/topic-884983-Banco-de-Dados-de-CEP-atualizado-novembro-2012.html)
