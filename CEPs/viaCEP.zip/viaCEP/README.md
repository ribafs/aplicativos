#API viaCEP#

INSTRUÇÕES PARA EXECUÇÃO.

-- Clone o Repositório GIT.

-- Execute o arquivo Banco.sql dentro do seu Banco de dados (no meu caso PHPMYADMIN).

-- Pesquise e encontre as informações do CEP desejado.

Att, Matheus Macrineu
